<?php
session_start();

if (!isset($_SESSION['user_users_id']) || empty($_SESSION['user_users_username'])) {
    $response = array(
        'error' => 'You are not logged in. Please log in to add items to your cart.',
        'redirect' => 'login_users.php' // Optionally provide a redirect URL
    );
    echo json_encode($response);
    exit; // Exit after sending the response
}

// Check if the user is logged in
if (!empty($_SESSION['user_users_id']) && !empty($_SESSION['user_users_username'])) {
    // User is logged in, proceed to fetch the cart data
    $id = $_GET['id'];
    
    if (empty($_SESSION['cart'])) {
        $_SESSION['cart'][] = $id;
    } else {
        if (!in_array($id, $_SESSION['cart'])) {
            $_SESSION['cart'][] = $id;
        }	
    }
    
    echo json_encode($_SESSION['cart']);
} else {
    // User is not logged in, return an error message
    $response = array(
        'error' => 'User not logged in. Please log in to add items to your cart.',
        'redirect' => 'login_users.php' // Optionally provide a redirect URL
    );	
    echo json_encode($response);
}
?>
