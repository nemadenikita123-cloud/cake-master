
<?php
session_start();

if (isset($_GET['remove_success']) && $_GET['remove_success'] == 1) {
    echo "<script>alert('Product removed!')</script>";
    echo "<script>window.location.assign('cart.php')</script>";
}

if (isset($_GET['order_success']) && $_GET['order_success'] == 1) {
    echo "<script>alert('Order placed!')</script>";
    echo "<script>window.location.assign('cart.php')</script>";
}

if (!empty($_SESSION['cart'])) {
    $printCount = count($_SESSION['cart']);
} else {
    $printCount = 0;
}

if (!empty($_SESSION['user_users_id']) && !empty($_SESSION['user_users_username'])) {
    $printUsername = $_SESSION['user_users_username'];
} else {
    $printUsername = "None";
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>OCS - Cart</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/userpage.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css">
    <style>
        .nav {
            background: url('uploads/nav.jpeg');
            background-size: cover;
            background-repeat: no-repeat;
            height: 100%;
        }

        .acc {
            background: url('uploads/back.jpeg');
            color: black;
        }

        .acc:hover {
            color: black;
        }

        .table-bordered th,
        .table-bordered td {
            border: 1px solid #dee2e6;
        }

        .table-bordered th {
            background-color: #39096C;
        }

        .table-bordered tr th {
            color: white;
        }

        .table-bordered tbody tr:hover {
            background-color: #f1f1f1;
        }

        .table-bordered tbody tr td {
            vertical-align: middle;
        }

        .bakery {
            background: url('uploads/bakery.jpeg');
            background-size: cover;
        }
    </style>
</head>

<body>
    <div class="dashboard-main-wrapper">
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="#"><img src="/cakemaster/uploads/logo.png" style="width:50%;" ></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span><i class="fas fa-bars mx-3"></i></span>
                </button>
                <div class="collapse navbar-collapse nav" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                    <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Shop</a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink1">
                            <?php
                            require_once('config.php');
                            $select = "SELECT * FROM cake_shop_category";
                            $query = mysqli_query($conn, $select);
                            while ($res = mysqli_fetch_assoc($query)) {
                            ?>
                                <a class="dropdown-item" href="shop.php?category=<?php echo $res['category_id'];?>">
                                    <?php echo $res['category_name'];?>
                                </a>
                            <?php
                            }
                            ?>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="cart.php"><i class="fas fa-shopping-cart"></i> <span class="badge badge-pill badge-secondary"><?php echo $printCount;?></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="uploads/default-image.jpg" alt="" class="user-avatar-md rounded-circle"></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown" aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info acc">
                                    <h5 class="mb-0 text-white nav-user-name accname"><?php echo $printUsername;?></h5>
                                    <span class="status"></span><span class="ml-2">Available</span>
                                </div>
                                <a class="dropdown-item" href="account_users.php"><i class="fas fa-user mr-2"></i>Account</a>
                                <a class="dropdown-item" href="login_users.php"><i class="fas fa-sign-in-alt mr-2"></i>Login</a>
                                <a class="dropdown-item" href="logout_users.php"><i class="fas fa-power-off mr-2"></i>Logout</a>
                                <a class="dropdown-item" href="admin/account_admin.php"><i class="fas fa-user mr-2"></i>Admin Login</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>

        <div class="container-fluid dashboard-content bakery">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" style="max-height: 200px; overflow-y: auto;">
                    <div class="page-header">
                        <h2 class="pageheader-title" style="color:white;">Cart</h2>
                        <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac porta, fusce sit amet vestibulum mi. Morbi lobortis pulvinar quam.</p>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb" style="font-size:20px">
                                <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-link">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page" style="color:black">Your cart</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mx-5" style="max-height: 430px; overflow-y: auto;">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>S. No</th>
                                            <th>Product Name</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Weight</th>
                                            <th>Total</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <form method="post" action="insert_orders.php">
                                        <tbody>
                                            <?php
                                            if ($printCount == 0) {
                                                echo '<tr><td colspan="7" align="center">Your cart is empty!<br><br><a href="index.php"> Explore Products </a></td></tr>';
                                            } else {
                                                $total_amount = 0;
                                                require_once('config.php');
                                                for ($i = 0; $i < count($_SESSION['cart']); $i++) {
                                                    $select = "SELECT * FROM cake_shop_product where product_id = {$_SESSION['cart'][$i]}";
                                                    $query = mysqli_query($conn, $select);
                                                    $j = $i;
                                                    while ($res = mysqli_fetch_assoc($query)) {
                                                        $total_amount += $res['product_price'];
                                            ?>
                                                        <tr>
                                                            <td><?php echo ++$j; ?></td>
                                                            <td><?php echo $res['product_name']; ?><input type="hidden" name="hidden_product_name[]" value="<?php echo $res['product_name']; ?>"></td>
                                                            <td>Rs. <?php echo $res['product_price']; ?><input type="hidden" name="hidden_product_price[]" value="<?php echo $res['product_price']; ?>"></td>
                                                            <td>
                                                                <input class="form-control" type="number" min="1" max="9" step="1" value="1" name="product_quantity[]" onchange="prodTotal(this)">
                                                            </td>
                                                            <td>
                                                                <select class="form-control" name="product_weight[]" onchange="updatePrice(this, <?php echo $res['product_price']; ?>, <?php echo $res['product_id']; ?>)">
                                                                    <option value="0.5">1/2 kg</option>
                                                                    <option value="1" selected>1 kg</option>
                                                                    <option value="2">2 kg</option>
                                                                </select>
                                                            </td>
                                                            <td>
                                                                <span id="product_total_<?php echo $res['product_id']; ?>">Rs. <?php echo $res['product_price'] * 1; ?></span>
                                                                <input type="hidden" name="hidden_product_total[]" value="<?php echo $res['product_price']; ?>">
                                                            </td>
                                                            <td align="center"><a href="remove_product.php?val_i=<?php echo $i; ?>"><i class="fas fa-trash-alt"></i></a></td>
                                                        </tr>
                                            <?php
                                                    }
                                                }
                                            ?>
                                            <tr>
                                                <td colspan="5" align="right">Total Amount:</td>
                                                <td colspan="2" id="total_amount">
                                                    <span>Rs. <?php echo ($printCount == 0) ? 0 : $total_amount; ?></span>
                                                    <input type="hidden" name="hidden_total_amount" value="<?php echo $total_amount; ?>">
                                                </td>
                                            </tr>
                                            <tr>
                                            <td colspan="3">
    Delivery Date:<input class="form-control" type="date" name="delivery_date" min="<?php echo date('Y-m-d'); ?>" required="">
</td>

                                                <td colspan="3">
                                                    Payment Method:<select class="form-control" name="payment_method" >
                                                        <option>Cash</option>
                                                        <option>Card</option>
                                                        <option onselect="alert('online');">Online Payment</option>
                                                    </select>
                                                </td>
                                                <td colspan="4" align="right">
                                                    <button class="btn btn-danger" onclick="clear_cart()">Clear</button>
                                                    <button class="btn btn-success" type="submit">Checkout</button>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </form>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div style="height:250px;"></div>
        </div>

        <div class="footer nav">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12" style="color:white">
                        Copyright © 2024 Concept. All rights reserved.
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                        <div class="text-md-right footer-links d-none d-sm-block">
                            <a href="javascript: void(0);" style="color:white">About</a>
                            <a href="javascript: void(0);" style="color:white">Support</a>
                            <a href="javascript: void(0);" style="color:white">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.bundle.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/main-js.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>

    <script>
function add_cart(product_id) {
    $.ajax({
        url: 'fetch_cart.php',
        data: 'id=' + product_id,
        method: 'get',
        dataType: 'json',
        success: function (response) {
            if (response.error) {
                alert(response.error); // Display the error message in an alert
                if (response.redirect) {
                    window.location.href = response.redirect; // Redirect to the specified URL if provided
                }
            } else {
                console.log(response); // Log the cart data
                $('.badge').html(response.length);
            }
        },
        error: function(xhr, status, error) {
            console.error(error); // Log any AJAX errors
        }
    });
}



    function clear_cart() {
        var flag = confirm("Do you want to clear cart?");
        if (flag) {
            window.location.href = "clear_cart.php";
        }
    }

    function updateFields(row) {
        var price = parseFloat(row.find('td:eq(2) input').val());
        var quantity = parseFloat(row.find('td:eq(3) input').val());
        var weight = parseFloat(row.find('td:eq(4) select').val());
        var total = quantity * price * weight;

        // Update total field in the current row
        row.find('td:eq(5) span').text("Rs. " + total.toFixed(2));

        // Update hidden input value for the current product
        row.find('td:eq(5) input').val(total.toFixed(2));

        // Trigger the recalculation of total amount
        updateTotalAmount();
    }

    function updatePrice(weightDropdown, basePrice, productId) {
        var row = $(weightDropdown).closest('tr');
        var selectedWeight = parseFloat(weightDropdown.value);

        // Update the weight in the hidden input
        row.find('td:eq(4) input').val(selectedWeight);

        updateFields(row);
    }

    function prodTotal(quantity) {
        var row = $(quantity).closest('tr');
        updateFields(row);
    }

    function updateTotalAmount() {
        var total_amount = 0;
        $('input[name="hidden_product_total[]"]').each(function () {
            total_amount += parseFloat($(this).val());
        });
        $('#total_amount').find('span').html("Rs. " + total_amount.toFixed(2));
        $('#total_amount').find('input').val(total_amount.toFixed(2));
    }
</script>

</body>

</html>
