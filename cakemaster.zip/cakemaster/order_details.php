<?php
require_once('config.php');
session_start();

// Get orders_id from the URL parameter
if (isset($_GET['orders_id'])) {
    $orders_id = $_GET['orders_id'];

    // Retrieve order details from the database
    $select_order_details = "SELECT * FROM cake_shop_orders WHERE orders_id = $orders_id";
    $result_order_details = mysqli_query($conn, $select_order_details);

    if ($result_order_details && mysqli_num_rows($result_order_details) > 0) {
        $row_order_details = mysqli_fetch_assoc($result_order_details);

        // Fetch other details like product_name and quantity from cake_shop_orders_detail table
        $select_orders_detail = "SELECT product_name, quantity FROM cake_shop_orders_detail WHERE orders_id = $orders_id";
        $result_orders_detail = mysqli_query($conn, $select_orders_detail);

        $product_name = $quantity = [];

        while ($row_orders_detail = mysqli_fetch_assoc($result_orders_detail)) {
            $product_name[] = $row_orders_detail['product_name'];
            $quantity[] = $row_orders_detail['quantity'];
        }

        // Retrieve user information from the database
        $user_id = $row_order_details['users_id'];
        $select_user_info = "SELECT * FROM cake_shop_users_registrations WHERE users_id = $user_id";
        $result_user_info = mysqli_query($conn, $select_user_info);

        if ($result_user_info && mysqli_num_rows($result_user_info) > 0) {
            $row_user_info = mysqli_fetch_assoc($result_user_info);
            $customer_name = $row_user_info['users_username'];
            $customer_address = $row_user_info['users_address'];
        } else {
            // User information not found
            // Handle this as per your application logic
        }

    } else {
        // Orders details not found
        header("Location: cart.php");
        exit();
    }
} else {
    // Invalid URL parameter
    header("Location: cart.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-image: url('/cakemaster/uploads/back.jpeg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            backdrop-filter: blur(15px); /* Blur effect */
        }

        .invoice-container {
            max-width: 800px;
            margin: auto;
            backdrop-filter: blur(15px); /* Blur effect */
            background:white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 15px; /* Rounded corners */
            backdrop-filter: blur(15px); /* Blur effect */
        }

        h2 {
            text-align: center;
            color:dodgerblue;
            color:#39096C;
        }

        .summary {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .summary h3 {
            color: #39096C;
        }

        .summary p {
            margin: 5px 0;
        }

        .print_button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        /* Hover effect */
        .print_button:hover {
            background-color: #45a049;
        }
        .product-summary {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.product-summary th,
.product-summary td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.product-summary th {
    background-color: #39096C;
    color: white;
}

    </style>
</head>
<body>
    <div class="invoice-container">
        <h2 >Order Summary</h2>
        <div class="order-summary">
   
    <p><strong>Order ID:</strong> <?php echo $orders_id; ?></p>
    <p><strong>Order Time:</strong> <?php echo date("F j, Y H:i:s"); ?></p>
    <p><strong>Restaurant Name:</strong> Bakecraft Provisions</p>
    <p><strong>Delivery Date:</strong> <?php echo $row_order_details['delivery_date']; ?></p>
    <p><strong>Payment Method:</strong> <?php echo $row_order_details['payment_method']; ?></p>
    <p><strong>Total Amount:</strong> <?php echo $row_order_details['total_amount']; ?></p>
    <p><strong>Customer Name:</strong> <?php echo $customer_name; ?></p>
<p><strong>Customer Address:</strong> <?php echo $customer_address; ?></p>

</div>


        <h2>Product Summary</h2>
        <?php
        if (!empty($product_name)) {
            ?>
<table style="width: 100%; border-collapse: collapse; margin-top: 20px; ">
    <tr>
        <th style="background-color: #0D759C; color: white; padding: 8px; text-align: left;">Product Name</th>
        <th style="background-color: #0D759C; color: white; padding: 8px; text-align: left;">Unit Price (₹)</th>
        <th style="background-color: #0D759C; color: white; padding: 8px; text-align: left;">Quantity</th>
        <th style="background-color: #0D759C; color: white; padding: 8px; text-align: left;">Total Price (₹)</th>
    </tr>
    <?php
    $total_order_amount = 0; // Variable to store the total order amount
    for ($i = 0; $i < count($product_name); $i++) {
        // Fetch the unit price from the database based on the product name
        $select_unit_price = "SELECT product_price FROM cake_shop_product WHERE product_name = '{$product_name[$i]}'";
        $result_unit_price = mysqli_query($conn, $select_unit_price);
        if ($result_unit_price && mysqli_num_rows($result_unit_price) > 0) {
            $row_unit_price = mysqli_fetch_assoc($result_unit_price);
            $unit_price = $row_unit_price['product_price'];
        } else {
            $unit_price = 'N/A'; // Unit price not found
        }

        // Calculate the total price for the current product
        $total_price = $unit_price * $quantity[$i];

        // Add the total price to the total order amount
        $total_order_amount += $total_price;
        ?>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd;"><?php echo $product_name[$i]; ?></td>
            <td style="padding: 8px; border: 1px solid #ddd;">₹<?php echo $unit_price; ?></td>
            <td style="padding: 8px; border: 1px solid #ddd;"><?php echo $quantity[$i]; ?></td>
            <td style="padding: 8px; border: 1px solid #ddd;">₹<?php echo $total_price; ?></td>
        </tr>
        <?php
    }
    ?>
     <tr>
        <td colspan="3" style="padding: 8px; background:#F0F1F1; text-align: right;"><strong>Total Amount:</strong></td>
        <td style="padding: 8px; background:#F0F1F1;"><strong>₹<?php echo $total_order_amount; ?></strong></td>
    </tr>
</table>



            <?php
        } else {
            echo "No order items found.";
        }
        ?>

        <p>This is Online Receipt</p>
        <br><br><br>
        <center>
            <button class="print_button" onclick="window.print();">Get Receipt</button>
        </center>
    </div>
    <div style="height:200px;"></div>
</body>
</html>
