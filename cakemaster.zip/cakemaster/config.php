<?php
$host = "localhost";
$config_username = "admin";
$password = "admin";
$db = "onlinecakeshop";
$conn = mysqli_connect($host, $config_username, $password, $db);
$admin_username="admin";
$admin_email="ad@cake.com";
$admin_password="admin123";

?>