-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2024 at 08:01 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinecakeshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cake_shop_admin_registrations`
--

CREATE TABLE `cake_shop_admin_registrations` (
  `admin_id` int(11) NOT NULL,
  `admin_username` varchar(100) NOT NULL,
  `admin_email` varchar(150) NOT NULL,
  `admin_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cake_shop_admin_registrations`
--

INSERT INTO `cake_shop_admin_registrations` (`admin_id`, `admin_username`, `admin_email`, `admin_password`) VALUES
(1, 'admin', 'ad@cake.com', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `cake_shop_category`
--

CREATE TABLE `cake_shop_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cake_shop_category`
--

INSERT INTO `cake_shop_category` (`category_id`, `category_name`, `category_image`) VALUES
(1, 'Cakes', '200731042405.jpg'),
(2, 'Pastries', '200731042031.jpeg'),
(3, 'Desserts', '200731042306.jpg'),
(4, 'Cookies', '200731042457.jpg'),
(5, 'Muffins', '240112095912.jpeg'),
(6, 'Bread', '240112100146.jpeg'),
(7, 'Cupcakes', '240113040009.jpg'),
(8, 'Pies', '240113040531.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `cake_shop_orders`
--

CREATE TABLE `cake_shop_orders` (
  `orders_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `delivery_date` varchar(100) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `total_amount` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cake_shop_orders`
--

INSERT INTO `cake_shop_orders` (`orders_id`, `users_id`, `delivery_date`, `payment_method`, `total_amount`) VALUES
(20, 4, '2024-03-02', 'Cash', '500');

-- --------------------------------------------------------

--
-- Table structure for table `cake_shop_orders_detail`
--

CREATE TABLE `cake_shop_orders_detail` (
  `orders_detail_id` int(11) NOT NULL,
  `orders_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cake_shop_orders_detail`
--

INSERT INTO `cake_shop_orders_detail` (`orders_detail_id`, `orders_id`, `product_name`, `quantity`) VALUES
(23, 15, ' chocolate muffins', 1),
(24, 15, 'Oatmeal Muffins with Dates, Cranberries & Pecans', 1),
(25, 16, ' chocolate muffins', 1),
(26, 16, ' Banana Muffins', 1),
(27, 17, 'Bread Cake', 1),
(28, 18, 'Oatmeal Muffins with Dates, Cranberries & Pecans', 1),
(29, 18, ' chocolate muffins', 1),
(30, 19, 'Strawberry', 1),
(31, 19, 'Butterscotch', 1),
(32, 19, 'Red Velvet Pastry', 1),
(33, 20, 'Red velvet', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cake_shop_product`
--

CREATE TABLE `cake_shop_product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_category` int(11) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_description` varchar(300) NOT NULL,
  `product_image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cake_shop_product`
--

INSERT INTO `cake_shop_product` (`product_id`, `product_name`, `product_category`, `product_price`, `product_description`, `product_image`) VALUES
(1, 'Black choco', 1, '500', 'This is cake made of pure chocolate.', '2007310437280.jpg, 2007310437281.jpg, 2007310437282.jpg'),
(2, 'Red velvet', 1, '500', 'This cake is inspired by red velvet.', '2007310439020.jpg, 2007310439021.jpg, 2007310439022.jpg'),
(3, 'Black forest', 1, '500', 'It is a simple black forest cake.', '2007310440210.jpg, 2007310440211.jpg, 2007310440212.jpg'),
(4, 'Oreo', 1, '500', 'Made out of oreo.', '2007310441020.jpg, 2007310441021.jpg, 2007310441022.jpg'),
(5, 'Black Choco', 2, '100', 'This is a black chocolate.', '2007310442250.jpg'),
(6, 'Strawberry', 2, '100', 'This is a strawberry.', '2007310443190.jpg'),
(7, 'Butterscotch', 2, '100', 'This is a butterscotch.', '2007310444030.jpg'),
(8, 'Choco chips', 4, '050', 'This a chocolate chip cookie.', '2007310445280.jpg'),
(9, 'Chocolate', 3, '025', 'Chocolate flavoured dessert.', '2007310446340.jpg'),
(10, 'Vanilla', 3, '025', 'Vanilla flavoured dessert.', '2007310448270.jpg'),
(11, 'Applesauce Muffins', 5, '100', ' You can make a different flavor every day of the month! Applesauce Muffins', '2401121005000.jpg'),
(12, ' chocolate muffins', 5, '150', 'A small-batch recipe for vegan decadent mini chocolate muffins for chocolate-mergencies.', '2401121006280.jpeg'),
(13, 'Chocolate Bread', 6, '120', 'This Is The Chocolate Bread>>>>', '2401121010090.jpeg'),
(14, 'Bread Cake', 6, '150', 'This Is the Bread Cake', '2401121010540.jpg'),
(15, 'Vanilla Bean Fantasy', 7, '130', 'This Is The Yummy Vanilla Bean Fantasy', '2401130402280.jpeg'),
(16, 'Chocolate Fudge Delight', 7, '140', 'Chocolate Fudge Delight The Taste Matters..!', '2401130403150.jpeg'),
(17, 'Strawberry Swirl Cupcake', 7, '160', 'Strawberry Swirl Cupcake, Have a Try..!', '2401130403530.jpeg'),
(18, 'Apple Cinnamon Dream Pie', 8, '160', ' Get The Taste Of Apple Cinnamon Dream Pie..!', '2401130408200.jpeg'),
(19, 'Pecan Praline Pie', 8, '170', 'Pecan Praline Pie', '2401130408530.jpeg'),
(21, 'Red Velvet Pastry', 2, '120', 'This Is Red Velvet Pastry>>!', '2401160124090.jpg'),
(22, 'Pineapple Pastries', 2, '100', 'Pineapple Pastries...!\r\n', '2401160126520.jpeg'),
(23, 'Peanut butter cookies', 4, '100', 'This Is Peanut butter cookies!', '2401160129390.jpeg'),
(24, 'Oatmeal raisin cookies', 4, '120', 'This is Oatmeal raisin cookies..', '2401160130560.jpeg'),
(25, 'Black and white cookies', 4, '120', 'This Is Black and white cookies', '2401160131550.jpeg'),
(26, 'Crinkle Cookies', 4, '130', 'Crinkle Cookies', '2401160133170.jpeg'),
(27, 'Custard tart', 3, '040', 'Custard tart', '2401160135280.jpeg'),
(28, 'American Pudding', 3, '045', 'American Pudding', '2401160136360.jpeg'),
(29, 'Banana split', 3, '050', 'Banana split', '2401160137390.jpeg'),
(30, 'Oatmeal Muffins with Dates, Cranberries & Pecans', 5, '100', 'Oatmeal Muffins with Dates, Cranberries & Pecans', '2401160140140.jpeg'),
(31, ' Banana Muffins', 5, '120', ' Banana Muffins', '2401160141500.jpeg'),
(32, ' Triple Chocolate Muffins', 5, '100', ' Triple Chocolate Muffins', '2401160143120.jpeg'),
(33, 'Mexican Hot Chocolate Cupcake.', 7, '100', 'Mexican Hot Chocolate Cupcake.', '2401160147080.jpeg'),
(34, 'Snowball Cupcake.', 7, '120', 'Snowball Cupcake.', '2401160147570.jpeg'),
(35, 'Corned beef pie', 8, '100', 'Corned beef pie', '2401160149270.jpeg'),
(36, 'Cobbler', 8, '100', 'Cobbler', '2401160150140.jpeg'),
(37, 'Coconut cream pie', 8, '120', 'Coconut cream pie', '2401160151240.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `cake_shop_users_registrations`
--

CREATE TABLE `cake_shop_users_registrations` (
  `users_id` int(11) NOT NULL,
  `users_username` varchar(100) NOT NULL,
  `users_email` varchar(150) NOT NULL,
  `users_password` varchar(100) NOT NULL,
  `users_mobile` varchar(50) NOT NULL,
  `users_address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cake_shop_users_registrations`
--

INSERT INTO `cake_shop_users_registrations` (`users_id`, `users_username`, `users_email`, `users_password`, `users_mobile`, `users_address`) VALUES
(3, 'Neha', 'coderneha22@gmail.com', 'coder123', '8999912345', 'Shiv colony'),
(4, 'roshan', 'roshan@gmail.com', 'Roshan@09', '8788889269', 'jalgaon');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cake_shop_admin_registrations`
--
ALTER TABLE `cake_shop_admin_registrations`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cake_shop_category`
--
ALTER TABLE `cake_shop_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `cake_shop_orders`
--
ALTER TABLE `cake_shop_orders`
  ADD PRIMARY KEY (`orders_id`);

--
-- Indexes for table `cake_shop_orders_detail`
--
ALTER TABLE `cake_shop_orders_detail`
  ADD PRIMARY KEY (`orders_detail_id`);

--
-- Indexes for table `cake_shop_product`
--
ALTER TABLE `cake_shop_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `cake_shop_users_registrations`
--
ALTER TABLE `cake_shop_users_registrations`
  ADD PRIMARY KEY (`users_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cake_shop_admin_registrations`
--
ALTER TABLE `cake_shop_admin_registrations`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cake_shop_category`
--
ALTER TABLE `cake_shop_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `cake_shop_orders`
--
ALTER TABLE `cake_shop_orders`
  MODIFY `orders_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `cake_shop_orders_detail`
--
ALTER TABLE `cake_shop_orders_detail`
  MODIFY `orders_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `cake_shop_product`
--
ALTER TABLE `cake_shop_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `cake_shop_users_registrations`
--
ALTER TABLE `cake_shop_users_registrations`
  MODIFY `users_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
