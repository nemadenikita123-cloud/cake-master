<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('/cakemaster/uploads/payment.jpg');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(6px);
            font-family: 'Arial', sans-serif;
        }

        form {
            max-width: 400px;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            backdrop-filter: blur(10px);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            text-align: center;
        }

        h1 {
            color: #333;
            font-size: 32px;
            margin-bottom: 20px;
        }

        /* Customize Razorpay button styles if needed */
        .razorpay-payment-button {
            background-color: #4CAF50;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .razorpay-payment-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form>
        <h1>Payment</h1>
        <div class="razorpay-embed-btn" data-url="https://pages.razorpay.com/pl_NO9nOucF7ZoI3A/view" data-text="Pay" data-color="#528FF0" data-size="medium">
  <script>
    (function(){
      var d=document; var x=!d.getElementById('razorpay-embed-btn-js')
      if(x){ var s=d.createElement('script'); s.defer=!0;s.id='razorpay-embed-btn-js';
      s.src='https://cdn.razorpay.com/static/embed_btn/bundle.js';d.body.appendChild(s);} else{var rzp=window['__rzp__'];
      rzp && rzp.init && rzp.init()}})();
  </script>
</div>
    
        <script src="https://rzp.io/l/iUzN5AUV0"></script>

        <script>
            window.addEventListener('beforeunload', function(event) {
                window.location.href = 'index.php';
            });
        </script>
    </form>
    <br><br>
</body>
</html>
